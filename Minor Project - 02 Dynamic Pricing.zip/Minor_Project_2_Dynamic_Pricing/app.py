import streamlit as st
import pandas as pd
import joblib
import os

st.set_page_config(
    page_title="Dynamic Pricing",
    page_icon="💰"
)

st.title("💰 Dynamic Pricing System")
st.write("Estimate a product price using sample market data.")

MODEL_PATH = "pricing_model.pkl"

if not os.path.exists(MODEL_PATH):
    st.error("Model Missing. First Run train_model.py")
    st.stop()

model = joblib.load(MODEL_PATH)

st.subheader("Enter Product Details")

base_price = st.number_input(
    "Base Price",
    min_value=1.0,
    value=500.0
)

demand = st.slider(
    "Demand Level",
    min_value=0,
    max_value=100,
    value=50
)

stock = st.slider(
    "Stock Level",
    min_value=0,
    max_value=100,
    value=50
)

competitor_price = st.number_input(
    "Competitor Price",
    min_value=1.0,
    value=500.0
)

if st.button("Predict Product Price"):

    features = pd.DataFrame([{
        "base_price": base_price,
        "demand": demand,
        "stock": stock,
        "competitor_price": competitor_price
    }])

    predicted_price = model.predict(features)[0]

    st.success(
        f"Estimated Product Price: ₹{predicted_price:.2f}"
    )

    st.caption(
        "Educational demo using synthetic data. "
        "Not a real market pricing recommendation."
    )