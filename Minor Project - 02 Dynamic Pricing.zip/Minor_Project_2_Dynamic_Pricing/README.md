# Dynamic Pricing System

## Project Description
A machine learning demonstration that estimates
product prices using sample market features.

## Technologies Used
- Python
- Pandas
- NumPy
- Scikit-learn
- Streamlit

## Features
- Enter base price
- Enter demand and stock levels
- Enter competitor price
- Predict estimated product price

## How To Run
1. Install requirements.
2. Run train_model.py.
3. Run app.py using Streamlit.

## Disclaimer
Uses synthetic data for educational purposes.