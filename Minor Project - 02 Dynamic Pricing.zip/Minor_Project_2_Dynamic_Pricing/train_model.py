import numpy as np
import pandas as pd
import joblib

from sklearn.ensemble import RandomForestRegressor

np.random.seed(42)

# Create Sample Training Data
n = 2000

base_price = np.random.uniform(100, 2000, n)
demand = np.random.uniform(0, 100, n)
stock = np.random.uniform(0, 100, n)
competitor_price = np.random.uniform(100, 2000, n)

demand_factor = 1 + (demand - 50) / 250
stock_factor = 1 - (stock - 50) / 500

target_price = (
    base_price
    * demand_factor
    * stock_factor
)

target_price = np.clip(
    target_price,
    0.5 * base_price,
    1.5 * base_price
)

data = pd.DataFrame({
    "base_price": base_price,
    "demand": demand,
    "stock": stock,
    "competitor_price": competitor_price,
    "target_price": target_price
})

X = data[
    [
        "base_price",
        "demand",
        "stock",
        "competitor_price"
    ]
]

y = data["target_price"]

model = RandomForestRegressor(
    n_estimators=100,
    random_state=42
)

model.fit(X, y)

joblib.dump(model, "pricing_model.pkl")

data.to_csv("pricing_data.csv", index=False)

print("Dynamic Pricing Model Created Successfully!")